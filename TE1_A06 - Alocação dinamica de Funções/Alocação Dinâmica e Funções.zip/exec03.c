#include <stdio.h>
#include <stdlib.h>

int main()
{

    int vet1[5] = {10, 20, 30, 40, 50};
    int *vet1Duplicado;
    int vet2[5] = {60, 70, 80, 90, 100};
    int *vet2Duplicado;

    vet1Duplicado = clonarVetor1(vet1);

    for (int i = 0; i < 5; i++)
    {
        printf("[%i] ", vet1Duplicado[i]);
    }

    clonarVetor2(vet2, &vet2Duplicado);

    for (int i = 0; i < 5; i++)
    {
        printf("[%i] ", vet2Duplicado[i]);
    }

    return 0;
}

int clonarVetor1(int *vet)
{

    int *vetor;
    vetor = calloc(5, sizeof(int));

    for (int i = 0; i < 5; i++)
    {
        vetor[i] = vet[i];
    }

    return vetor;
}

int clonarVetor2(int *vet, int *saida)
{

    int *vetor;
    vetor = calloc(5, sizeof(int));

    for (int i = 0; i < 5; i++)
    {
        vetor[i] = vet[i];
    }

    *saida = vetor;
}